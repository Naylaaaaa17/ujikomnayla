<?php
include "database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $task_id = $_POST["task_id"];
    $title = $_POST["title"]; // sesuai form

    if (!empty($title)) {
        $query = "INSERT INTO subtasks (task_id, title) VALUES ('$task_id', '$title')";
        mysqli_query($conn, $query) or die("Query Error: " . mysqli_error($conn));
    }

    header("Location: index.php");
    exit;
}
?>
