<?php
session_start();
include "database.php";

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "ID tugas tidak ditemukan!";
    exit;
}

$task_id = $_GET['id'];

// Ambil data task dari database
$query = "SELECT * FROM tasks WHERE id = $task_id";
$result = mysqli_query($conn, $query);
$task = mysqli_fetch_assoc($result);

if (!$task) {
    echo "Tugas tidak ditemukan!";
    exit;
}

if (isset($_POST['update'])) {
    $title = htmlspecialchars($_POST['title']);
    $deadline = $_POST['deadline'];
    $priority = $_POST['priority'];

    $update_query = "UPDATE tasks SET title='$title', deadline='$deadline', priority='$priority' WHERE id = $task_id";
    if (mysqli_query($conn, $update_query)) {
        header("Location: index.php");
    } else {
        echo "Gagal memperbarui tugas.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Tugas</title>
    <link rel="stylesheet" href="stylee.css">
</head>
<body>
<div class="todo-container">
    <h2>Edit Tugas</h2>
    <form action="" method="post" class="task-form">
        <input type="text" name="title" value="<?php echo htmlspecialchars($task['title']); ?>" required>
        <input type="date" name="deadline" value="<?php echo $task['deadline']; ?>" required>
        <select name="priority">
            <option value="Low" <?php if ($task['priority'] == 'Low') echo 'selected'; ?>>Low</option>
            <option value="Medium" <?php if ($task['priority'] == 'Medium') echo 'selected'; ?>>Medium</option>
            <option value="High" <?php if ($task['priority'] == 'High') echo 'selected'; ?>>High</option>
        </select>
        <button type="submit" name="update">Simpan Perubahan</button>
    </form>
    <a href="index.php" class="btn">🔙 Kembali</a>
</div>
</body>
</html>
