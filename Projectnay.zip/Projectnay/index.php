<?php
session_start();
include "database.php";

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// Ambil user_id
$user_query = mysqli_query($conn, "SELECT id FROM users WHERE username='$username'");
$user_data = mysqli_fetch_assoc($user_query);
$user_id = $user_data['id'];

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>To-Do List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="todo-container">
        <h2>To-Do List</h2>
        <p>Selamat datang, <?php echo htmlspecialchars($username); ?>! <a href="logout.php" class="btn logout">🚪 Logout</a></p>

        <!-- Form Tambah Tugas -->
        <form action="add_task.php" method="post" class="task-form">
            <input type="text" name="title" placeholder="Masukkan Nama Tugas" required>
            <input type="date" name="deadline" required>
            <select name="priority">
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
            </select>
            <button type="submit">Tambah Tugas</button>
        </form>

        <ul class="task-list">
        <?php
        $query = "SELECT * FROM tasks WHERE user_id = $user_id ORDER BY deadline ASC";
        $result = mysqli_query($conn, $query);

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<li class='task-item'>";
            echo "<span class='task-title'>" . htmlspecialchars($row['title']) . " (" . $row['priority'] . ") - " . $row['deadline'] . "</span>";
            echo "<a href='delete.php?id=" . $row['id'] . "' class='delete-btn' onclick='return confirm(\"Hapus tugas ini?\")'>❌ Hapus</a>";
            echo "<a href='edit_task.php?id=" . $row['id'] . "' class='edit-btn'>✏️ Edit</a>";

            // Ambil subtasks
            $task_id = $row['id'];
            $subtask_query = "SELECT * FROM subtasks WHERE task_id = $task_id";
            $subtask_result = mysqli_query($conn, $subtask_query);

            if (mysqli_num_rows($subtask_result) > 0) {
                echo "<ul class='subtask-list'>";
                while ($subtask = mysqli_fetch_assoc($subtask_result)) {
                    $subtask_title = isset($subtask['title']) ? htmlspecialchars($subtask['title']) : "Subtask tidak ditemukan!";
                    $checked = !empty($subtask['is_completed']) ? "checked" : "";
                    echo "<li class='subtask-item'>";
                    echo "<input type='checkbox' class='subtask-checkbox' $checked>";
                    echo "<span class='subtask-text'>" . htmlspecialchars($subtask['title']) . "</span>";
                    echo "</li>";
                    
                    

                }
                echo "</ul>";
            } else {
                echo "<p class='no-subtasks'>Tidak ada subtask</p>";
            }

            // Form tambah subtask
            echo "<form action='add_subtask.php' method='post' class='subtask-form'>";
            echo "<input type='hidden' name='task_id' value='" . $row['id'] . "'>";
            echo "<input type='text' name='title' placeholder='Tambah subtask' required>";
            echo "<button type='submit'>Tambah</button>";
            echo "</form>";

            echo "</li>";
        }
        ?>
        </ul>

        <!-- Riwayat Aktivitas -->
        <h3>Riwayat Aktivitas</h3>
        <ul class="history-list">
            <?php
            $history_query = "SELECT h.*, t.title FROM history h 
                            JOIN tasks t ON h.task_id = t.id 
                            WHERE t.user_id = $user_id 
                            ORDER BY h.timestamp DESC LIMIT 10";
            $history_result = mysqli_query($conn, $history_query);
            while ($history = mysqli_fetch_assoc($history_result)) {
                echo "<li>📌 " . htmlspecialchars($history['title']) . " - " . htmlspecialchars($history['action']) . " (" . $history['timestamp'] . ")</li>";
            }
            ?>
        </ul>
    </div>
</body>
</html>
