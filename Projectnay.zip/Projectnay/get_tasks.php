<?php
include "database.php";

$query = "SELECT * FROM tasks ORDER BY deadline ASC";
$result = mysqli_query($conn, $query);

$tasks = [];
while ($row = mysqli_fetch_assoc($result)) {
    $tasks[] = $row;
}

echo json_encode($tasks);
?>
