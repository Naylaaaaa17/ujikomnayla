<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include "database.php";

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    die("Error: User tidak ditemukan. Silakan login kembali.");
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $task_description = mysqli_real_escape_string($conn, $_POST['task_description'] ?? ''); // optional
    $deadline = $_POST['deadline'];
    $priority = $_POST['priority']; // 🟢 Ambil priority dari form

    // Sesuaikan dengan nama kolom di database
    $query = "INSERT INTO tasks (user_id, title, description, deadline, priority) 
              VALUES ('$user_id', '$title', '$task_description', '$deadline', '$priority')";

    if (mysqli_query($conn, $query)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
