<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['login'])) {
    header("Location: login.php"); // Redirect jika belum login
    exit;
}

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dashboard-container">
        <h2>Selamat Datang, <?php echo htmlspecialchars($username); ?>!</h2>
        <p>Kelola jadwal harianmu dengan To-Do List.</p>
        <div class="dashboard-buttons">
            <a href="index.php" class="btn">📋 To-Do List</a>
            <a href="logout.php" class="btn logout">🚪 Logout</a>
        </div>
    </div>
</body>
</html>
