<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include "database.php";

if (!isset($_SESSION['user_id'])) {
    die("Error: Anda harus login terlebih dahulu.");
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Error: ID tugas tidak valid.");
}

$task_id = intval($_GET['id']);

// Hapus subtasks terlebih dahulu jika ada
$query_delete_subtasks = "DELETE FROM subtasks WHERE task_id = ?";
$stmt = mysqli_prepare($conn, $query_delete_subtasks);
mysqli_stmt_bind_param($stmt, "i", $task_id);
mysqli_stmt_execute($stmt);

// Hapus tugas utama
$query_delete_task = "DELETE FROM tasks WHERE id = ? AND user_id = ?";
$stmt = mysqli_prepare($conn, $query_delete_task);
mysqli_stmt_bind_param($stmt, "ii", $task_id, $_SESSION['user_id']);
$delete_result = mysqli_stmt_execute($stmt);

if ($delete_result) {
    echo '<script>alert("Tugas berhasil dihapus!"); location.href="index.php";</script>';
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
