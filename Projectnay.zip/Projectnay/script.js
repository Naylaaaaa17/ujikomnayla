document.addEventListener("DOMContentLoaded", function () {
    loadTasks();

    document.getElementById("task-form").addEventListener("submit", function (e) {
        e.preventDefault();
        addTask();
    });
});

function loadTasks() {
    fetch("get_tasks.php")
        .then(response => response.json())
        .then(tasks => {
            let taskList = document.getElementById("task-list");
            taskList.innerHTML = "";
            tasks.forEach(task => {
                let li = document.createElement("li");
                li.innerHTML = `
                    <strong>${task.title}</strong> (${task.priority}) - ${task.deadline}
                    <p>${task.description}</p>
                    <button onclick="updateTask(${task.id}, 'Completed')">Selesai</button>
                    <button onclick="deleteTask(${task.id})">Hapus</button>
                `;
                taskList.appendChild(li);
            });
        });
}

function addTask() {
    let formData = new FormData();
    formData.append("title", document.getElementById("title").value);
    formData.append("description", document.getElementById("description").value);
    formData.append("priority", document.getElementById("priority").value);
    formData.append("deadline", document.getElementById("deadline").value);

    fetch("add_task.php", { method: "POST", body: formData })
        .then(() => loadTasks());
}

function updateTask(id, status) {
    fetch("update_task.php", { 
        method: "POST", 
        body: new URLSearchParams({ task_id: id, status: status })
    }).then(() => loadTasks());
}

function deleteTask(id) {
    fetch("delete_task.php", { 
        method: "POST", 
        body: new URLSearchParams({ task_id: id })
    }).then(() => loadTasks());
}
